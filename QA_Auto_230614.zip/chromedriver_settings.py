import webdriver_manager
from webdriver_manager.chrome import ChromeDriverManager
from selenium import webdriver
class chromedriver_settings:
    def chromedriverSettings():
        #chromedriver 경로 설정
        chrome_options = webdriver_manager.ChromeOptions()
        chrome_options.add_argument('--start-maximized')
        
