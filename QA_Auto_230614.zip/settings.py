class settings:

    #login info
    consoleid = 'auto_kade2@stclab.com'
    password = 'qwe123!!'

    # PASS / FAIL count info
    Passcount = 0
    FailCount = 0

    #sleep 시간
    sec = 1


    # Card info
    cardNumber = '4242 4242 4242 4242' 
    expiredDate = '202910'  
    cvcNumber = '123'
    birthDate = '910831' 

    #회원가입 반복 수
    signCount = 1
    
    #URL info
    loginurl = "https://qa-console.surffy-dev.io/ko/signin/"
    basic = "https://qa-console.surffy-dev.io/ko/byol/console/product/nf/65/controls/basic/default"
    segURL = "http://heart.stclab.com:5002/"

    signupurl = "https://qa-console.surffy-dev.io/ko/signup"

    #N번째 회원가입 
    num = 3